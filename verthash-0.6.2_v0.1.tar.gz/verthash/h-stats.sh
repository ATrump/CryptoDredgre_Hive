#!/usr/bin/env bash

#######################
# Functions
#######################

get_cards_hashes(){
#[2021-02-05 01:39:11] INFO  cu_device(3): hashrate: 213.16 kH/s
#[2021-02-05 01:39:11] INFO  cl_device(2): hashrate: 191.13 kH/s
  hs=''; local t_hs=0; cu_c=$((GPU_COUNT_AMD)); cl_c=0
  local i=0
  for b in $brands; do
   if [[ $b == "nvidia" ]]; then
    t_hs=`cat $log_name | tail -n 50 | grep "cu_device($cu_c)" | tail -n 1 | awk '{printf $6}'`
    hs+=\"$t_hs\"" "
    ((cu_c++))
   fi
   if [[ $b == "amd" ]]; then
    t_hs=`cat $log_name | tail -n 50 | grep "cl_device($cl_c)" | tail -n 1 | awk '{printf $6}'`
    hs+=\"$t_hs\"" "
    ((cl_c++))
   fi
  done
}


get_total_hashes(){
#[2021-02-05 01:44:06] INFO  accepted: 267/398 (67.09%), total hashrate: 1247.45 kH/s
  khs=0
  ac=`cat $log_name | tail -n 50 | grep "total hashrate" | tail -n 1 | awk '{print $5}' | cut -f 1 -d "/" -s`
  rj=`cat $log_name | tail -n 50 | grep "total hashrate" | tail -n 1 | awk '{print $5}' | cut -f 2 -d "/" -s`
  ((rj=rj-ac))
  khs=`cat $log_name | tail -n 50 | grep "total hashrate" | tail -n 1 | awk '{printf $9}'`
}

get_miner_uptime(){
  local a=0
  let a=`stat --format='%Y' $log_name`-`stat --format='%Y' $conf_name`
  echo $a
}

get_log_time_diff(){
  local a=0
  let a=`date +%s`-`stat --format='%Y' $log_name`
  echo $a
}

#######################
# MAIN script body
#######################

. /hive/miners/custom/$CUSTOM_MINER/h-manifest.conf
local log_name="$CUSTOM_LOG_BASENAME.log"
local conf_name="/hive/miners/custom/$CUSTOM_MINER/$CUSTOM_MINER.conf"

local temp=
local fan=
local ac=0
local rj=0


# Calc log freshness
local diffTime=$(get_log_time_diff)
local maxDelay=120

# echo $diffTime

local algo="verthash"

# If log is fresh the calc miner stats or set to null if not
if [ "$diffTime" -lt "$maxDelay" && -f $log_name ]; then
  local temp=$(jq -c '.temp' <<< $gpu_stats)
  local fan=$(jq -c '.fan' <<< $gpu_stats)
  bus_numbers=`echo $gpu_detect_json | jq -r ".[].busid[0:2]" |  awk '{printf("%d\n", "0x"$1)}' | jq -cs '.'`
  brands=`echo $gpu_detect_json | jq -r ".[].brand"`
  [[ $cpu_indexes_array != '[]' ]] && #remove Internal Gpus
    temp=$(jq -c "del(.$cpu_indexes_array)" <<< $temp) &&
    fan=$(jq -c "del(.$cpu_indexes_array)" <<< $fan) &&
    bus_numbers=$(jq -c "del(.$cpu_indexes_array)" <<< $bus_numbers)

  get_cards_hashes # hashes, temp, fan array
  get_total_hashes # total hashes, accepted, rejected
  local hs_units='khs' # hashes utits
  local uptime=$(get_miner_uptime) # miner uptime


# make JSON
#--argjson hs "`echo ${hs[@]} | tr " " "\n" | jq -cs '.'`" \
  stats=$(jq -nc \
        --argjson hs "`echo ${hs[@]} | tr " " "\n" | jq -cs '.'`" \
        --arg hs_units "$hs_units" \
        --argjson temp "`echo ${temp[@]} | tr " " "\n" | jq -cs '.'`" \
        --argjson fan "`echo ${fan[@]} | tr " " "\n" | jq -cs '.'`" \
        --arg ac "$ac" --arg rj "$rj" \
        --arg uptime "$uptime" \
        --arg algo "$algo" \
        --argjson bus_numbers "$bus_numbers" \
        '{$hs, $hs_units, $temp, $fan, $uptime, $algo, ar: [$ac, $rj], $bus_numbers'})
else
  stats=""
  khs=0
fi

# debug output
#echo "temp:         $temp"
#echo "fan:          $fan"
#echo "bus_numbers:  $bus_numbers"
#echo "brands:       $brands"
#echo stats: $stats
#echo khs:   $khs
