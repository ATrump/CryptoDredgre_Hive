#!/usr/bin/env bash

bin_name=$1
tmp_dir=$2

cmd_line=`ps aux | grep -v "h-umount_tmpfs.sh" | grep -v "grep" | grep ./VerthashMiner`

if [[ -z $cmd_line ]]; then
  while [[ -e $tmp_dir/verthash.dat ]]; do

    rm -rf $tmp_dir/verthash.dat
    umount -f $tmp_dir

  done
  crontab -l | grep -v "$0" | crontab -
fi
