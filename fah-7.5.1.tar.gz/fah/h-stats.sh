#!/usr/bin/env bash

#######################
# Functions
#######################


get_cards_hashes(){
local i_bus=
local gpu_count=`cat $log_name | grep " GPUs: " | cut -f 13 -d " "`
for (( i=0; i < $gpu_count; i++ )); do
  i_bus=`cat $log_name | grep " GPU $i: " | cut -f 13 -d " " | cut -f 2 -d ":"`
  bus_numbers+=" $i_bus"
  hs+=" 1"
  ((khs++))
done
}

get_miner_uptime(){
  local a=0
  let a=`stat --format='%Y' $log_name`-`stat --format='%Y' $conf_name`
  echo $a
}

get_log_time_diff(){
  local a=0
  let a=`date +%s`-`stat --format='%Y' $log_name`
  echo $a
}

#######################
# MAIN script body
#######################

. /hive/miners/custom/$CUSTOM_MINER/h-manifest.conf
local log_name="$CUSTOM_LOG_BASENAME.log"
local conf_name="/hive/miners/custom/$CUSTOM_MINER/config.xml"

local temp=$(jq '.temp' <<< $gpu_stats)
local fan=$(jq '.fan' <<< $gpu_stats)
cat $conf_name | grep -q "\-\-enable-cpu"
if [[ $? -eq 0 ]]; then
  [[ $cpu_indexes_array != '[]' ]] && #remove Internal Gpus
    temp=$(jq -c "del(.$cpu_indexes_array)" <<< $temp) &&
    fan=$(jq -c "del(.$cpu_indexes_array)" <<< $fan)
fi

khs=0
hs=
bus_numbers=

# Calc log freshness
local diffTime=$(get_log_time_diff)
local maxDelay=320

# If log is fresh the calc miner stats or set to null if not
if [ "$diffTime" -lt "$maxDelay" ]; then
  get_cards_hashes # hashes array
  local hs_units='khs' # hashes utits
  local uptime=$(get_miner_uptime) # miner uptime

# make JSON
#--argjson hs "`echo ${hs[@]} | tr " " "\n" | jq -cs '.'`" \
  stats=$(jq -nc \
        --argjson hs "`echo ${hs[@]} | tr " " "\n" | jq -cs '.'`" \
        --arg hs_units "$hs_units" \
        --argjson temp "$temp" \
        --argjson fan "$fan" \
        --arg ver "$CUSTOM_VERSION" \
        --argjson bus_numbers "`echo ${bus_numbers[@]} | tr " " "\n" | jq -cs '.'`" \
        --arg algo "uknown" \
        '{$hs, $hs_units, $bus_numbers, $temp, $fan, uptime: '$uptime', $ver, $algo}')
else
  stats=""
  khs=0
fi

# debug output
##echo temp:  $temp
##echo fan:   $fan
#echo stats: $statsOD
#echo khs:   $khs
