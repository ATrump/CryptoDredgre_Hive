#!/usr/bin/env bash

cd `dirname $0`

[ -t 1 ] && . colors

. h-manifest.conf

[[ `ps aux | grep "./FAHClient" | grep -v grep | wc -l` != 0 ]] &&
  while killall FAHClient; do sleep 1; done
#  echo -e "${RED}$MINER_NAME miner is already running${NOCOLOR}" &&
#  exit 1

CUSTOM_LOG_BASEDIR=`dirname "$CUSTOM_LOG_BASENAME"`
[[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR

./FAHClient --power=full --core-dir=/run/hive/miners/fah/ --data-directory=/run/hive/miners/fah/ --log=$CUSTOM_LOG_BASENAME.log --log-color=false --log-redirect=true --log-rotate=false --log-truncate=true 2>&1

