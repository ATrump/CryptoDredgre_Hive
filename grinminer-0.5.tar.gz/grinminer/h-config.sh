#!/usr/bin/env bash

[[ -z $CUSTOM_TEMPLATE ]] && echo -e "${YELLOW}CUSTOM_TEMPLATE is empty${NOCOLOR}" && return 1
[[ -z $CUSTOM_URL ]] && echo -e "${YELLOW}CUSTOM_URL is empty${NOCOLOR}" && return 1
[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && return 1
[[ -z $CUSTOM_LOG_BASENAME ]] && echo -e "${RED}No CUSTOM_LOG_BASENAME is set${NOCOLOR}" && exit 1

echo "$conf" > $CUSTOM_CONFIG_FILENAME
echo "[logging]" > $CUSTOM_CONFIG_FILENAME
echo "log_to_stdout = true" >> $CUSTOM_CONFIG_FILENAME
echo "stdout_log_level = \"Info\"" >> $CUSTOM_CONFIG_FILENAME
echo "log_to_file = true" >> $CUSTOM_CONFIG_FILENAME
echo "file_log_level = \"Debug\"" >> $CUSTOM_CONFIG_FILENAME
echo "log_file_path = \"${CUSTOM_LOG_BASENAME}.log\"" >> $CUSTOM_CONFIG_FILENAME
echo "log_file_append = true" >> $CUSTOM_CONFIG_FILENAME

echo "[mining]" >> $CUSTOM_CONFIG_FILENAME
echo "run_tui = true" >> $CUSTOM_CONFIG_FILENAME
local pool=`head -n 1 <<< "$CUSTOM_URL"`
echo "stratum_server_addr = \"$pool\"" >> $CUSTOM_CONFIG_FILENAME
echo "stratum_server_login = \"$$CUSTOM_TEMPLATE\"" >> $CUSTOM_CONFIG_FILENAME
echo "stratum_server_password = \"$CUSTOM_PASS\"" >> $CUSTOM_CONFIG_FILENAME
echo "stratum_server_tls_enabled = false" >> $CUSTOM_CONFIG_FILENAME

echo "#####CUSTOM_USER_CONFIG#####" >> $CUSTOM_CONFIG_FILENAME

for line in ${CUSTOM_USER_CONFIG}; do
  echo $line >> $CUSTOM_CONFIG_FILENAME
done

