#!/usr/bin/env bash

[[ `ps aux | grep "./VerthashMiner" | grep -v "h-umount_tmpfs.sh" | grep -v "grep" | wc -l` != 0 ]] &&
  echo -e "${RED}$MINER_NAME miner is already running${NOCOLOR}" &&
  exit 1

. /hive/miners/custom/verthash/h-manifest.conf

CUSTOM_LOG_BASEDIR=`dirname "$CUSTOM_LOG_BASENAME"`
[[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR

tmp_dir=/hive/miners/custom/verthash/tmpfs
/hive/miners/custom/verthash/h-umount_tmpfs.sh /hive/miners/custom/verthash/VerthashMiner $tmp_dir

[[ ! -d $tmp_dir ]] && mkdir -p $tmp_dir
mount -t tmpfs -o size=1225M tmpfs $tmp_dir

(crontab -l; echo "*/1 * * * * /hive/miners/custom/verthash/h-umount_tmpfs.sh /hive/miners/custom/verthash/VerthashMiner $tmp_dir") | crontab -

cd /hive/miners/custom/verthash
if [[ ! -f /hive/miners/custom/verthash/tmpfs/verthash.dat ]]; then
  wd delay 15
  ./VerthashMiner --gen-verthash-data /hive/miners/custom/verthash/tmpfs/verthash.dat
  wd restart
fi

./VerthashMiner `cat verthash.conf` 2>&1 | tee $CUSTOM_LOG_BASENAME.log

