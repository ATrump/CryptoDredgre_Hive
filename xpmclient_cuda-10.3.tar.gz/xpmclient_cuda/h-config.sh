#!/usr/bin/env bash
# This code is included in /hive/bin/custom function

. /hive/miners/custom/$CUSTOM_NAME/h-manifest.conf
#log=/hive/miners/custom/finminer/test.log

[[ -z $CUSTOM_TEMPLATE ]] && echo -e "${YELLOW}CUSTOM_TEMPLATE is empty${NOCOLOR}" && return 1
[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && return 1

mkfile_from_symlink $CUSTOM_CONFIG_FILENAME

host=`echo $CUSTOM_URL | cut -d ':' -f 1`
port=`echo $CUSTOM_URL | cut -d ':' -f 2`
wallet=`echo $CUSTOM_TEMPLATE | cut -d '.' -f 1`
worker=`echo $CUSTOM_TEMPLATE | cut -d '.' -f 2`

cat /hive/miners/custom/$CUSTOM_NAME/config.global > $CUSTOM_CONFIG_FILENAME

sed -i --follow-symlinks "s#.*server = .*#server = \"$host\";#gi" $CUSTOM_CONFIG_FILENAME
sed -i --follow-symlinks "s#.*port = .*#port = \"$port\";#gi" $CUSTOM_CONFIG_FILENAME
sed -i --follow-symlinks "s#.*address = .*#address = \"$wallet\";#gi" $CUSTOM_CONFIG_FILENAME
if [[ ! -z $XPMCLIENT_WORKER ]]; then
  sed -i --follow-symlinks "s#.*name = .*#name = \"$worker\";#gi" $CUSTOM_CONFIG_FILENAME
else
  sed -i --follow-symlinks "s#.*name = .*##gi" $CUSTOM_CONFIG_FILENAME
fi

#merge user config options into main config
if [[ ! -z $CUSTOM_USER_CONFIG ]]; then
  while read -r line; do
    [[ -z $line ]] && continue
    local param_name=`echo $line | cut -d '=' -f 1`'='
    [[ ${line:$((${#line}-1)):1} != ';' ]] && line+=';'
    if [[ `cat $CUSTOM_CONFIG_FILENAME | grep -c "$param_name"` -gt 0 ]]; then
      sed -i --follow-symlinks "s#.*$param_name.*#${line//\"/\\\"}#gi" $CUSTOM_CONFIG_FILENAME
    else
      echo $line >> $CUSTOM_CONFIG_FILENAME
    fi
  done <<< "$CUSTOM_USER_CONFIG"
fi

