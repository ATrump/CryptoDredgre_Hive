#!/usr/bin/env bash

cd `dirname $0`

[ -t 1 ] && . colors
. h-manifest.conf

echo $CUSTOM_NAME
echo $CUSTOM_LOG_BASENAME
echo $CUSTOM_CONFIG_FILENAME

[[ -z $CUSTOM_LOG_BASENAME ]] && echo -e "${RED}No CUSTOM_LOG_BASENAME is set${NOCOLOR}" && exit 1
[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && exit 1
[[ ! -f $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}Custom config ${YELLOW}$CUSTOM_CONFIG_FILENAME${RED} is not found${NOCOLOR}" && exit 1

#[[ `ps aux | grep "./xpmclient" | grep -v grep | wc -l` != 0 ]] &&
#  echo -e "${RED}$MINER_NAME miner is already running${NOCOLOR}" &&
#  exit 1

miner_run_dir="/run/hive/miners/$CUSTOM_NAME"

ln -sfn /hive/miners/custom/$CUSTOM_NAME/xpm $miner_run_dir/xpm
ln -sf /hive/miners/custom/$CUSTOM_NAME/xpmclient $miner_run_dir/xpmclient
ln -sf /hive/lib/libnvrtc-builtins.so.10.0.130 $miner_run_dir/libnvrtc-builtins.so
ln -sf /hive/lib/libnvrtc.so.10.0.130 $miner_run_dir/libnvrtc.so.10.0

cd $miner_run_dir
if [[ -f version ]]; then
  if [[ `cat version` != $CUSTOM_VERSION ]]; then
    #remove *.bin becouse it had been created with other miner version
    rm -f *.bin
    echo $CUSTOM_VERSION > version
  fi
else
  rm -f *.bin
  echo $CUSTOM_VERSION > version
fi

# Miner run here
LD_LIBRARY_PATH=/hive/lib ./xpmclient 2>&1 | tee --append $CUSTOM_LOG_BASENAME.log

