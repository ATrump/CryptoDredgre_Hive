#!/usr/bin/env bash

[[ `ps aux | grep "./VerthashMiner" | grep -v grep | wc -l` != 0 ]] &&
  echo -e "${RED}$MINER_NAME miner is already running${NOCOLOR}" &&
  exit 1

tmp_dir=/hive/miners/custom/$CUSTOM_MINER/tmpfs
/hive/miners/custom/$CUSTOM_MINER/h-umount_tmpfs.sh /hive/miners/custom/$CUSTOM_MINER/VerthashMiner $tmp_dir

[[ ! -d $tmp_dir ]] && mkdir -p $tmp_dir
mount -t tmpfs -o size=1225M tmpfs $tmp_dir

  (crontab -l; echo "*/1 * * * * /hive/miners/custom/$CUSTOM_MINER/h-umount_tmpfs.sh /hive/miners/custom/$CUSTOM_MINER/VerthashMiner $tmp_dir") | crontab -
fi

cd /hive/miners/custom/$CUSTOM_MINER
./VerthashMiner `cat miner.conf` 2>&1 | tee $CUSTOM_LOG_BASENAME.log
